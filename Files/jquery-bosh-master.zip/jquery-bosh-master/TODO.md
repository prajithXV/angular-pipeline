* Improve included chat client
* Implement MUCs
* Increased testing
* Make roster more robust
* Ferret out edge cases of ingesting packets immediately upon login
* Implement DIGEST-MD5 (only PLAIN is currently supported)