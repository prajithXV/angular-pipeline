({
    baseUrl: ".",
    name: "node_modules/almond/almond.js",
    mainConfigFile: "main.js",
    include: ["strophe"],
    wrap: {
        startFile: "src/start.frag",
        endFile: "src/end.frag"
    }
})
